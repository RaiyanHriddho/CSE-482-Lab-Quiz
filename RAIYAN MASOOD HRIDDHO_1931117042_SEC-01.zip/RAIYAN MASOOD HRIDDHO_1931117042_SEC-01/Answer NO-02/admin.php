<?php

$greekMythology = array(
    "Zeus" => array(
        "Description" => "Zeus is the king of the Greek gods and the god of the sky, lightning, and thunder.",
        "Symbols" => "Thunderbolt, eagle, oak tree",
    ),
    "Athena" => array(
        "Description" => "Athena is the goddess of wisdom, courage, and warfare strategy.",
        "Symbols" => "Owl, olive tree, aegis (shield)",
    ),
    "Medusa" => array(
        "Description" => "Medusa is a Gorgon, a creature with snakes for hair, and anyone who gazes upon her is turned to stone.",
        "Symbols" => "Snakes, stone gaze",
    ),
    "Hercules" => array(
        "Description" => "Hercules is a demigod known for his incredible strength and his famous Twelve Labors.",
        "Symbols" => "Club, lion's skin",
    ),
    "Cerberus" => array(
        "Description" => "Cerberus is the three-headed dog guarding the entrance to the underworld, preventing the dead from leaving.",
        "Symbols" => "Three heads, chains",
    ),
);

function getCharacterInfo($name) {
    global $greekMythology;
    if (array_key_exists($name, $greekMythology)) {
        $character = $greekMythology[$name];
        echo "<h1>$name<h1>";
        echo "<p>strong>Description:</strong> " .$character["Description"] . "</p>";
        echo "<p>strong>Symbols:</strong> " .$character["Symbols"] . "</p>";
    } else {
        echo "Character not found.";
    }
}

if (isset($_POST["characterName"])){
    $characterName = $_POST["characterName"];
    getCharacterInfo($characterName);
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Greek Mythologival Characters</title>
</head>
<body>
    <h1>Enter the name of a Greekmythological character:</h1>
    <form method="post">
        <input type="text" name="characterName" required>
        <input type="submit" name="Retrive Information">
</form>
</body>
</html>
