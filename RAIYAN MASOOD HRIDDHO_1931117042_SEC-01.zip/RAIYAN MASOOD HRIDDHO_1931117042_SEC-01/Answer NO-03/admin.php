<?php
// Sample data
$gods = [
    [
        'Name' => 'Athena',
        'Description' => 'Athena is the goddess of wisdom, courage, and warfare strategy',
        'Symbols' => ['Owl', 'olive tree', 'aegis'],
    ],
    // Add more gods here
];

// Function to search for a god by name or symbols
function searchGods($searchTerm, $gods) {
    $results = [];

    foreach ($gods as $god) {
        // Check if the search term matches the name
        if (strcasecmp($searchTerm, $god['Name']) === 0) {
            $results[] = $god;
        } else {
            // Check if the search term matches any symbol
            foreach ($god['Symbols'] as $symbol) {
                if (stripos($symbol, $searchTerm) !== false) {
                    $results[] = $god;
                    break; // No need to check other symbols for this god
                }
            }
        }
    }

    return $results;
}

// Sample input
$searchTerm = 'Aegis';

// Search for gods by name or symbols
$results = searchGods($searchTerm, $gods);

// Display the results
if (empty($results)) {
    echo "No matching gods found for '$searchTerm'.";
} else {
    foreach ($results as $result) {
        echo "Name: {$result['Name']}\n";
        echo "Description: {$result['Description']}\n";
        echo "Symbols: " . implode(', ', $result['Symbols']) . "\n\n";
    }
}
?>
