const tableData = [
    "415=5",
    "Fage",
    "2 1=22 2 4 2B6",
    "31- 332-6 33=934 123515",
    "4-1= 442 =84 3=1244 164 =20",
    "51=552= 10",
    "5155=2055 25",
    "61- 662= 126 31864 2465=30",
    "S25=10"

];

function printTable(data) {
    for (let i = 0; i < data.length; i++) {
        console.log(data[i]);
    }
}

printTable(tableData);
    
